package com.example.doce_do_bom;

import android.graphics.Typeface;

public class Fontes {
    //Variáveis
    static Typeface fontLovely, fontCane;
}
