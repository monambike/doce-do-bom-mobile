package com.example.doce_do_bom;

public class Dados {
    //Usuário
    static String userId, userNome, userEmail, userSenha, userCPF, userDisponibilidade;
    static byte[] userFoto;
    static Integer userOpcao;
    //static byte[] userFotologin;

    //Produto
    static String productNome, productDescricao, productPreco;
    static Integer productImagem;
    static Boolean productDisponibildiade;

    //Dados de conexão
    static StringBuffer stringBuffer;
    static String ip = "10.0.0.17";
    //public static SQLHelper sqlHelper;
}
